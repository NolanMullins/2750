/****************************************
 * Nolan Mullins
 * 0939720
 * 19/03/2017
 * 2750 - A3
 ****************************************/

    This program is a message management and viewing system. It will store messages
along with the user's data. The viewer will be able to move through mosts, sort them
and reload them. It will allow the user to access this functionality through a web interface.

Known issues
 - Dont try to submit " its just not fun :(


/**********************************/
	Instructions - compile
		type: make
		output:
		a2/post
		a2/addauthor
		a3
/**********************************/

/**********************************/
	Instructions - run
	
	go to index.php

	to run the parser 
	./a3 file.wpml
/**********************************/

/**********************************/
	Additional info
	
	adding hidden="name", hVal="0"
	to buttons and input fields in the 
	wpml files will add a hidden value 
	to the component
/**********************************/