#ifndef __MULLINSN_GEN__
#define __MULLINSN_GEN__

#include "list.h"

void gen(List* data, char* user, char* stream, int index, int size, int order, int flag);

#endif