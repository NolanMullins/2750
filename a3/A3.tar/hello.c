#include <stdio.h>

int main()
{
    printf("Hello world plz work .php");
    return 0;
}
