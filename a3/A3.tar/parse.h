#ifndef __MULLINSN_PARSE__
#define __MULLINSN_PARSE__

#include "list.h"

List* parse(char* fileName);

#endif